
public class LiteraleTest {

	public static void main(String[] args) {
		// seit Java 7
		int x = 12_345_456;
		x = 0b11010101_10111011;
		
		x = 0xff_67_AB;

	}

}
