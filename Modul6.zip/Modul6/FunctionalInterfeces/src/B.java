
public class B implements A, C{

	@Override
	public void test() {
		System.out.println("public void test()  in Klasse B");
		
	}

	@Override
	public void testDefaultObject() {
		A.super.testDefaultObject();
		C.super.testDefaultObject();
		 System.out.println("testDefaultObject() in B");
	 }
	
}
