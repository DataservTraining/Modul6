package streams;
import java.util.ArrayList;
import java.util.List;

public class A6 {

	public static void main(String[] args) {
		final List<String> names = new ArrayList<>();
		names.add("Michael");
		names.add("Tim");
		names.add("Flo");
		names.add("Clemens");
		
		names.stream().map(s -> s.startsWith("M") ? ">>" + s.toUpperCase() + "<<" : s).forEach(System.out::println);

	}

}
