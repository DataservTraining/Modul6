package streams;
import java.util.function.Predicate;

public class A2 {

	public static void main(String[] args) {
		final Predicate<Integer> isEven = i -> i % 2 == 0;
		final Predicate<Integer> isOdd = Predicate.not((isEven));
		final Predicate<Integer> isPositive = i -> i >= 0;
		final Predicate<Integer> isNegative = isPositive.negate();
		final Predicate<Integer> isEvenAndPositive = isEven.and(isPositive);

		final Predicate<String> isShortWord = str -> str.length() < 4;

		

	}

}
