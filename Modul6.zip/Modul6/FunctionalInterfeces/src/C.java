
public interface	 C {
	 public default void testDefaultObject() {
		 System.out.println("testDefaultObject() in C");
	 }
}
