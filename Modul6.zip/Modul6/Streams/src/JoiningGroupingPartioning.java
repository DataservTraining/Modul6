import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class JoiningGroupingPartioning {

	static int anzahl = 0;
	public static void main(String[] args) {
		final List<String> names = Arrays.asList("Stefan", "Ralph", "Andi", "Mike",	"Florian", "Michael", "Sebastian");
				
		final String joined = names.stream().sorted().collect(Collectors.joining(", ", anzahl != 0 ? "Namesliste: " : "", " :Ende"));
		final String joined2 = names.stream().sorted().collect(Collectors.collectingAndThen(Collectors.toList(), l -> { return l.size() != 0 ? "Prefix: " + String.join(", ", l.toArray(new String[0])) + " :Sufix" : "";}));
				Map<Integer, List<String>> grouped = names.stream().collect(Collectors.groupingBy(String::length));
				Map<Integer, Long> counting = names.stream().collect(Collectors.groupingBy(String::length, Collectors.counting()));
				
				System.out.println(joined);
				System.out.println(joined2);
				System.out.println(grouped);
				System.out.println(counting);
				
				final Map<Boolean, List<String>> partitioned = names.stream().filter(str -> str.contains("i")).collect(Collectors.partitioningBy(str-> str.length() > 4));
				
				System.out.println(partitioned);

	}

}
