import java.time.DayOfWeek;

public class StringsInSwitch {

	public static void main(String[] args) {
		String text = "Hallo Welt";

		switch (text) {
		case "Hallo":
			System.out.println("Hallo");
			break;
		case "Welt":
			System.out.println("...");
		}

		DayOfWeek day = DayOfWeek.FRIDAY;
		
		int numOfLetters;
		switch (day) {
		case MONDAY:
		case FRIDAY:
		case SUNDAY:
			numOfLetters = 6;
			break;
		case TUESDAY:
			numOfLetters = 7;
			break;
		case THURSDAY:
		case SATURDAY:
			numOfLetters = 8;
			break;
		case WEDNESDAY:
			numOfLetters = 9;
			break;
		default:
			numOfLetters = -1;
		}
		
		
		// seit Java 14
		numOfLetters = switch(day) {
		case MONDAY, FRIDAY, SUNDAY -> 6;
		
		default -> -1;
		};
		
		String text2 = "fsjfk sdjklhskjfh sdkkfj dfsjjhkjsdh kj "
				        + "fdjs fsdkjhf kds";
		
		
		// seit Java 15
		String text3 = """
				sjdkah sdakfjh sdkjfh sldkfjf fdsa
				sdkjh gskjdfjk shklsdhjsd
				s dfkjsdfjk hsdkjfhsdkj fh
				sdjfkl hkljsdfhkjsdafsd
				sdkjf sdkjahf ksjhdf fk
				""";

	}

}
