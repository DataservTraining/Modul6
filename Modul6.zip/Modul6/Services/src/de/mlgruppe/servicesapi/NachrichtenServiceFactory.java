package de.mlgruppe.servicesapi;

import de.mlgruppe.services.NachrichtenServiceImpl;

public class NachrichtenServiceFactory {
	
	public static NachrichtenService getNachrichtenService() {
		return new NachrichtenServiceImpl("Nachricht aus der Factory!");
	}

}
