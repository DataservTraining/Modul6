import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class DateTimeFormatterTest {

	public static void main(String[] args) {
		// Definition einiger spezieller Formatter
		final DateTimeFormatter ddMMyyyyFormat = DateTimeFormatter.ofPattern("dd.MM.yyyy");
		final DateTimeFormatter italian_dMMMMyy = DateTimeFormatter.ofPattern("d.MMMM y", Locale.ITALIAN);
//		Locale.setDefault(Locale.ITALIAN);
		final DateTimeFormatter shortGerman = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT);
		// Achtung: Die textuellen Teile sind in Hochkomma einzuschlie�en
		final String customPattern = "'Der 'dd'. Tag im 'MMMM' im Jahr 'yyyy'.'";
		final DateTimeFormatter customFormat = DateTimeFormatter.ofPattern(customPattern);
		// Mapping f�r verschiedene Formate definieren

		final Map<String, DateTimeFormatter> formatters = new LinkedHashMap<>();
		formatters.put("BASIC_ISO_DATE", DateTimeFormatter.BASIC_ISO_DATE);
		formatters.put("ISO_DATE_TIME", DateTimeFormatter.ISO_DATE_TIME);
		formatters.put("dd.MM.yyyy", ddMMyyyyFormat);
		formatters.put("d.MMMM y (it)", italian_dMMMMyy);
		formatters.put("SHORT_GERMAN", shortGerman);
		formatters.put("CUST OM_FORMAT", customFormat);
		System.out.println("Formatting: n");
		applyFormatters(LocalDateTime.of(2014, Month.MAY, 28, 1, 2, 3), formatters);
		// Parsen von Datumswerten
		System.out.println("Parsing: ");
		final LocalDate fromIsoDate = LocalDate.parse("1971-02-07");
		final LocalDate fromCustomPattern = LocalDate.parse("18.03.2014", ddMMyyyyFormat);
		final LocalDateTime fromShortGerman = LocalDateTime.parse("18.03.14, 11:12", shortGerman);
		System.out.println("From ISO Date: " + fromIsoDate);
		System.out.println("From custom pattern: " + fromCustomPattern);
		System.out.println("From short german: " + fromShortGerman);

	}

	private static void applyFormatters(final LocalDateTime base, final Map<String, DateTimeFormatter> formatters) {
			System.out.println("Starting on: " + base);
			formatters.forEach((name, formatter) -> System.out.println("applying �" + name + "�: " + base.format(formatter)));
	}

}
