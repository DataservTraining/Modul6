
public class Start {

	public static void main(String[] args) {
		B b = new B();
		b.test();
		b.testDefaultObject();
		A.publicStaticMethode();

	}

}
