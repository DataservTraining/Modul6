package filtermapreduce;

public class A3 {

	public static void main(String[] args) {
		final String[] namesArray = { "Tim", "Tom", "Andy", "Mike", "Merten" };
		

	}

}
