import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;

public class SumCountEtc {

	public static void main(String[] args) {
		final List<Person> persons = new ArrayList<>();
		persons.add(new Person("Ten", 10));
		persons.add(new Person("Twenty", 20));
		persons.add(new Person("Thirty", 30));
		persons.add(new Person("Forty", 40));
		
		long count = persons.stream().filter(person -> person.getName().startsWith("T")).count();
		System.out.println("count: " + count);
		
		int alter = persons.stream().mapToInt(Person::getAge).sum();
		System.out.println("Alter: " + alter);
		
		OptionalDouble durchschnittsalter = persons.stream().filter(p -> p.getName().contains("T")).mapToInt(Person::getAge).average();
		System.out.println("Durchschnittsalter: " + durchschnittsalter);
		System.out.println("Min-Alter: " + persons.stream().mapToInt(Person::getAge).min());
		System.out.println("Max-Alter: " + persons.stream().mapToInt(Person::getAge).max());

	}

}
