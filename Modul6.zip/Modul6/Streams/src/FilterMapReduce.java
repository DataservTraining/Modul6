import java.time.LocalDate;
import java.time.Month;
import java.util.Arrays;
import java.util.List;

public class FilterMapReduce {
	
	private static final List<Person> persons = Arrays.asList(
			new Person("Stefan", LocalDate.of(1971, Month.MAY, 12)),
			new Person("Micha", LocalDate.of(1971, Month.FEBRUARY, 7)),
			new Person("Andi Bubolz", LocalDate.of(1968, Month.JULY, 17)),
			new Person("Andi Steffen", LocalDate.of(1970, Month.JULY, 17)),
			new Person("Merten", LocalDate.of(1975, Month.JUNE, 16)));

	public static void main(String[] args) {
		
		String namen = persons.stream().
				filter(p -> p.getGeburtsdatum().getMonth().equals(Month.JULY)).
				map(p -> p.getName()).
				reduce("", (s1, s2) -> !s1.isEmpty() ? s1 + ", " + s2 : s2);
		System.out.println(namen);
		
	}

}
