import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Start1 {

	public static void main(String[] args) {
		final String[] namesData = { "Karl", "Ralph", "Andi", "Andy", "Mike" };
		final List<String> names = Arrays.asList(namesData);
		final Stream<String> streamFromArray = Arrays.stream(namesData);
		final Stream<String> streamFromList = names.stream();
		final Stream<String> namesStream = Stream.of("Tim", "Andy", "Mike"); // String
		final Stream<Integer> integers = Stream.of(1, 4, 7, 7, 9, 7, 2); 
		
		final IntStream valuesInt = IntStream.range(0, 100);
		final IntStream chars = "This is a test".chars();
		
		streamFromArray.forEach(System.out::println);
		streamFromList.forEach(System.out::println);
		namesStream.forEach(System.out::println);
		integers.forEach(System.out::println);
		valuesInt.forEach(System.out::println);
		chars.forEach(System.out::println);
		
		final List<String> names2 = Arrays.asList("Mike", "Stefan", "Nikolaos");
				Stream<String> values = names2.stream(). // --> Stream<String>
				mapToInt(String::length).                // --> Stream
				parallel().
				asLongStream().                          // -->	LongStream
				boxed().                                 // -->	Stream<Long>
				mapToDouble(x -> x * 0.75).	            // -->	DoubleStream
				sequential().
				mapToObj(val -> "Val: " +	val);	    // -->	Stream<String>
				
				
				values.forEach(System.out::println);
				
				System.out.println("=========================================");
				
				final IntStream iteratingValues = IntStream.iterate(0, x -> x + 1);
				final AtomicInteger ai = new AtomicInteger(0);
				final Stream<Integer> generatedValues = Stream.generate(ai::getAndIncrement);
						
				final int[] firstTen = iteratingValues.skip(25).limit(10).toArray();
				final Object[] secondTen = generatedValues.skip(4).limit(10).toArray();
				System.out.println(Arrays.toString(firstTen));
				System.out.println(Arrays.toString(secondTen));
		
	}

}
