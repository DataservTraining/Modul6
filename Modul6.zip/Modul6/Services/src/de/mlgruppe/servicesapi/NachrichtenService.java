package de.mlgruppe.servicesapi;

public interface NachrichtenService {
	
	public abstract String getNachricht();

}
