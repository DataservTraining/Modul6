package de.mlgruppe.services;

import de.mlgruppe.servicesapi.NachrichtenService;

public class NachrichtenServiceImpl implements NachrichtenService {
	private String message;
	
	public NachrichtenServiceImpl(String message) {
		super();
		this.message = message;
	}

	@Override
	public String getNachricht() {
		return this.message;
	}

}
