package streams;
import java.util.ArrayList;
import java.util.List;

public class A5 {

	public static void main(String[] args) {
		final List<String> names = new ArrayList<>();
		names.add("Michael");
		names.add("Tim");
		names.add("Flo");
		names.add("Clemens");
		
		names.stream().filter(name -> name.length() >= 4).forEach(System.out::println);
		names.removeIf(name -> name.length() < 4);
		
		names.forEach(System.out::println);
		

	}

}
