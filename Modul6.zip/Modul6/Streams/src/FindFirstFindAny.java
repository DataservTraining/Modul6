import java.util.ArrayList;
import java.util.List;

public class FindFirstFindAny {

	public static void main(String[] args) {
		
		List<Integer> zahlen = new ArrayList();
		for(int i = 0; i < 50; ++i) zahlen.add((int) (Math.random() * 10 + 1));
		zahlen.forEach(z -> System.out.print(z + ", "));
		System.out.println();
		
		
		System.out.println(zahlen.stream().findFirst());
		System.out.println();
		System.out.println(zahlen.stream().findAny());
	}

}
