package de.mlgruppe.nachrichtenbeispiel;

import de.mlgruppe.servicesapi.NachrichtenService;
import de.mlgruppe.servicesapi.NachrichtenServiceFactory;

public class Start {

	public static void main(String[] args) {
		NachrichtenService service = NachrichtenServiceFactory.getNachrichtenService();
		
		System.out.println(service.getNachricht());

	}

}
