import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class MultiCatchBloecke {

	public static void main(String[] args) {

		int x = 7, y = 0, erg;
		
		
		try (FileWriter in = new FileWriter(""); 
				ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("")); 
				Scanner scanner = new Scanner(System.in)) {
			erg = x/y;
			
		} catch(ArithmeticException | IOException e) {
			
		} finally {
			
		}

	}

}
