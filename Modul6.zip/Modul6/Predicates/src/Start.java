import java.util.List;
import java.util.function.Predicate;

public class Start {

	public static void main(String[] args) {
		// Pr�dikate formulieren
		final Predicate<String> isNull = str -> str == null;
		final Predicate<String> isEmpty = String::isEmpty;
		final Predicate<Person> isAdult = person -> person.getAge() >= 18;
		System.out.println("isNull(''): " + isNull.test(null));
		System.out.println("isEmpty(''): " + isEmpty.test(""));
		System.out.println("isEmpty(�Pia�): " + isEmpty.test("Pia"));
		System.out.println("isAdult(Pia): " + isAdult.test(new Person("Pia", 55)));
		
		final List<Person> persons = DemoData.createDemoData();
		System.out.println(persons);

		final Predicate<Person> isMale = person -> person.getGender() == Gender.MALE;
		// Negation einzelner Pr�dikate
		final Predicate<Person> isYoung = isAdult.negate();
		final Predicate<Person> isFemale = isMale.negate();
		final Predicate<Person> isFemale2 = Predicate.not(isMale);
		
		// Kombination von Pr�dikaten mit AND
		final Predicate<Person> boys = isMale.and(isYoung);
		final Predicate<Person> women = isFemale.and(isAdult);
		// Kombination von Pr�dikaten mit OR
		final Predicate<Person> boysOrWomen = boys.or(women);
		
//		DemoData.removeAll(persons, boysOrWomen);
		persons.removeIf(boysOrWomen);
		System.out.println(persons);
		
	}

}
