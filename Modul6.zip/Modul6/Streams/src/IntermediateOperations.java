import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class IntermediateOperations {

	public static void main(String[] args) {
		final List<Person> persons = new ArrayList<>();
		persons.add(new Person("Micha", 34, "Berlin"));
		persons.add(new Person("Micha", 43, "Z�rich"));
		persons.add(new Person("Barbara", 40, Gender.FEMALE, "Hamburg"));
		persons.add(new Person("Yannis", 5, "Hamburg"));

		Predicate<Person> isAdult = person -> person.isAdult();
		
		Stream<Person> personenStream = persons.stream().
				                                filter(isAdult);
//				                                filter(person -> person.getName().equals("Micha"));
//				                                filter(person -> person.livesIn("Z�rich"));
		
		personenStream.forEach(System.out::println);
		
		Stream<Integer> alter = persons.stream().map(person -> person.getAge());
		
		alter.forEach(System.out::println);
		
		Stream<String> orte = persons.stream().map(Person::getCity).distinct();
		orte.forEach(System.out::println);
		
		IntStream alter2 = persons.stream().mapToInt(Person::getAge).sorted();
		alter2.forEach(System.out::println);
		
		System.out.println("--------------------------");
		
		Stream<Integer> alter3 = persons.stream().map(Person::getAge).sorted((e1, e2) -> Integer.compare(e2, e1));
		alter3.forEach(System.out::println);
	}

}
