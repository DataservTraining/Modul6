import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class StatistischeWerte {

	public static void main(String[] args) {
		final Map<String, Collector<Integer, ?, ?>> collectorsMap = new LinkedHashMap<>();
		collectorsMap.put("counting(): ", Collectors.counting());
		collectorsMap.put("summingInt(): ", Collectors.summingInt(x -> x));
		collectorsMap.put("averagingInt(): ", Collectors.averagingInt(x -> x));
		collectorsMap.put("maxBy(): ", Collectors.maxBy(Integer::compare));
		collectorsMap.put("minBy(): ", Collectors.minBy(Integer::compare));
		collectorsMap.put("summarizingInt(): ", Collectors.summarizingInt(x -> x));

		
		final List<Integer> ints = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		
		for (final var mapping : collectorsMap.entrySet()) {
			final Collector<Integer, ?, ?> collector = mapping.getValue();
			System.out.println(mapping.getKey() + ints.stream().collect(collector));
		}

	}

}
