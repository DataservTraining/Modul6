
public class Start {

	public static void main(String[] args) {
		 java.lang.Runtime.Version version = Runtime.version();
		 
		 System.out.println("*".repeat(30));
		 Thread thread = new Thread();
		 

	}

}
