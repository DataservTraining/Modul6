module NachrichtenBeispiel {
	requires Services;
 	
}