import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CollectTest {

	public static void main(String[] args) {
		Stream<Integer> agesStream = DemoData.createDemoData().stream().map(Person::getAge);
		
		List<Integer> ageList = agesStream.collect(Collectors.toList());
		System.out.println(ageList);
		
		agesStream = DemoData.createDemoData().stream().map(Person::getAge);
		List<Integer> ageArrayList = agesStream.collect(Collectors.toCollection(ArrayList::new));
		System.out.println(ageArrayList);

	}

}
