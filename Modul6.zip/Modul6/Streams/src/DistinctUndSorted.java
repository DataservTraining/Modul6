import java.util.stream.IntStream;
import java.util.stream.Stream;

public class DistinctUndSorted {

	public static void main(String[] args) {
		Stream<Integer> zahlen =  Stream.of(7, 1, 4, 3, 7, 2, 6, 5, 7, 9, 8);
		Stream<Integer> distinct = zahlen.distinct();
		zahlen =  Stream.of(7, 1, 4, 3, 7, 2, 6, 5, 7, 9, 8);
		Stream<Integer> sorted = zahlen.sorted();
		zahlen =  Stream.of(7, 1, 4, 3, 7, 2, 6, 5, 7, 9, 8);
		Stream<Integer> distinctAndSorted = zahlen.distinct().sorted();
		
		distinct.forEach(i -> System.out.print(i + ", "));
		System.out.println();
		sorted.forEach(i -> System.out.print(i + ", "));
		System.out.println();
		distinctAndSorted.forEach(i -> System.out.print(i + ", "));
	}

}
