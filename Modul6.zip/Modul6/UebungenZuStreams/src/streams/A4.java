package streams;
import java.util.Arrays;
import java.util.List;

public class A4 {

	public static void main(String[] args) {
		final List<String> names = Arrays.asList("Tim", "Peter", "Mike", "Andy");
		
		names.stream().sorted((s1, s2) -> s1.compareTo(s2)).forEach(System.out::println);
		System.out.println("=====================");
		names.stream().sorted(String::compareTo).forEach(System.out::println);
	}

}
