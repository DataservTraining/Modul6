package filtermapreduce;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class A2 {

	public static void main(String[] args) {
		final String[] namesArray = { "Tim", "Tom", "Andy", "Mike", "Merten" };
		
		Object[] objectArray = Arrays.stream(namesArray).toArray();
		List<String> liste = Arrays.stream(namesArray).collect(Collectors.toList());
		

	}

}
