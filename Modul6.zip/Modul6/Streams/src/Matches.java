import java.util.Arrays;
import java.util.List;

public class Matches {

	public static void main(String[] args) {
		final List<String> names = Arrays.asList("Tim", "Tom", "Micha");
		
		System.out.println("AllMatch: " + names.stream().allMatch(p -> p.startsWith("T")));
		System.out.println("AnyMatch: " + names.stream().anyMatch(p -> p.startsWith("T")));
		System.out.println("noneMatch: " + names.stream().noneMatch(p -> p.startsWith("T")));

	}

}
