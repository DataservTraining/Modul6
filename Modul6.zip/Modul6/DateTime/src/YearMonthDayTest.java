import java.time.Month;
import java.time.MonthDay;
import java.time.Year;
import java.time.YearMonth;

public class YearMonthDayTest {

	public static void main(String[] args) {
		YearMonth September2001  = YearMonth.of(2001, Month.SEPTEMBER);
		System.out.println("September2001: " + September2001);
		
		MonthDay _09September = MonthDay.of(Month.SEPTEMBER, 11);
		System.out.println("_09September: " + _09September);
		
		Year year = Year.of(2004);
		System.out.println("year: " + year + " Schaltjahr? " + year.isLeap());
		System.out.println("year: " + year + " 29.02 g�ltig? " + year.isValidMonthDay(MonthDay.of(2, 29)));
		System.out.println(year + " ist vor Jahr 2022: " + year.isAfter(Year.now()));
		

	}

}
