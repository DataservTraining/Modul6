import java.time.LocalDate;
import java.time.Month;

public class NextPaydayAdjusterTest {

	public static void main(String[] args) {
		final LocalDate jan = LocalDate.of(2018, Month.NOVEMBER, 30);
		final LocalDate nextPayday1 = jan.with(new NextPaydayAdjuster());
		final LocalDate feb = LocalDate.of(2018, Month.FEBRUARY, 7);
		final LocalDate nextPayday2 = feb.with(new NextPaydayAdjuster());
		System.out.println("Next Payday Jan: " + nextPayday1);
		System.out.println("Next Payday Feb: " + nextPayday2);

	}

}
