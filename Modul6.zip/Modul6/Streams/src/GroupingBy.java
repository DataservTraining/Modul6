import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class GroupingBy {

	public static void main(String[] args) {
		final List<Person> persons = DemoData.createPersons();
		System.out.println("grouped by city");
		System.out.println(persons.stream().collect(Collectors.groupingBy(Person::getCity)));
		System.out.println("grouped by own region classifier");
		final Function<Person, String> byRegion = DemoData.createRegionClassifier();
		System.out.println(persons.stream().collect(Collectors.groupingBy(byRegion)));
		System.out.println("ngrouped by region and calculation average age");
		System.out.println(persons.stream().collect(Collectors.groupingBy(byRegion, Collectors.averagingInt(Person::getAge))));
		System.out.println(" ngrouped by region and calculation statistics");
		System.out.println(persons.stream().collect(Collectors.groupingBy(byRegion, Collectors.summarizingInt(Person::getAge))));

	}

}
