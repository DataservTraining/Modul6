import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.Temporal;
import java.time.temporal.TemporalAdjuster;
import java.time.temporal.TemporalAdjusters;

public class NextPaydayAdjuster implements TemporalAdjuster {
	@Override
	public Temporal adjustInto(final Temporal temporal) {
		LocalDate date = LocalDate.from(temporal);
		
		boolean isDecember = date.getMonth().equals(Month.DECEMBER);
		int paymentDay = isDecember ? 15 : 25;
		if(date.getDayOfMonth() > paymentDay) {
			date = date.plusMonths(1);
			isDecember = date.getMonth().equals(Month.DECEMBER);
			paymentDay = isDecember ? 15 : 25;
			
		}
		
		date = date.withDayOfMonth(paymentDay);
		
		if(date.getDayOfWeek() == DayOfWeek.SATURDAY || date.getDayOfWeek() == DayOfWeek.SUNDAY) {
			date = isDecember ? date.with(TemporalAdjusters.next(DayOfWeek.MONDAY)) : date.with(TemporalAdjusters.previous(DayOfWeek.FRIDAY));
		}
		
		
		return temporal.with(date);
	}
}