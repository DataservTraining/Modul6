package filtermapreduce;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class A1 {

	public static void main(String[] args) {
		//1a: Create Intermediate, Terminal
		
		// 1b
		final String[] namesArray = { "Tim", "Tom", "Andy", "Mike", "Merten" };
		final List<String> names = Arrays.asList(namesArray);
		final Stream<String> streamFromArray = Arrays.stream(namesArray);
		final Stream<String> streamFromList = names.stream();
		final Stream<String> streamFromValues = Stream.of("Tim", "Tom", "Andy", "Mike", "Merten");
		
		// 1c
		
		final Stream<String> filtered = streamFromList.filter(n -> n.startsWith("T"));
		final Stream<String> mapped = filtered.map(String::toUpperCase);

		names.stream().filter(n -> n.startsWith("T")).forEach(System.out::println);
		streamFromArray.map(String::toUpperCase).forEach(System.out::println);

	}

}
