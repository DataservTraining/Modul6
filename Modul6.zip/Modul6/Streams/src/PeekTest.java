import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class PeekTest {

	
	
	public static void main(String[] args) {
		
		Consumer<Person> personenConsumer = p -> {
			 System.out.println(" Schritt 1: " + p);
		};
		
		
		Consumer<String> stringConsumer = p -> {
			System.out.println(" Schritt 1: " + p);
		};
		
		

		List<Person> persons = DemoData.createDemoData();
		
		Stream<String> namen = persons.stream().
								peek(s -> ausgabe(s, 1)).
								filter(p -> p.getAge() >= 18).
								peek(s -> ausgabe(s, 2)).
								map(Person::getName).
								peek(s -> ausgabe(s, 3)).
								filter(n -> n.startsWith("Mi")).
								peek(s -> ausgabe(s, 4)).
								map(n -> n.toUpperCase());
		
		
		
		namen.forEach(e -> System.out.println(" Schritt 5: " + e));
		
	}

	private static <T> void ausgabe(T s, int i) {
		System.out.println(" Schritt " + i + ": " + s);
	}

}
