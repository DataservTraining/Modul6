
// seit Java 8 (SAM- Typen)
@FunctionalInterface
public interface A {
 public static final int X = 56; // implicite public static final 
 
 public abstract void test();  // implicite public abstract 
 public abstract boolean equals (Object o);  // Methode aus der Klasse Object 
 
 
 // seit Java 8 Default-Implementierung
 public default void testDefaultObject() {
	 System.out.println("testDefaultObject() in A");
	 testPrivateObject();
	 testPrivateStatic();
 }
 
 public static void publicStaticMethode() {
	 System.out.println("publicStaticMethode() ");
	 testPrivateStatic();
 }
 
 
 // seit Java 9
 private void testPrivateObject() {
	 System.out.println("void testPrivateObject()");
 }
 
 private static void testPrivateStatic() {
	 System.out.println("void testPrivateStatic()");
 }
 
 
 
}
