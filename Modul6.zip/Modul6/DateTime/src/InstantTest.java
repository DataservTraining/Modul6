import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

public class InstantTest {

	public static void main(String[] args) {
		// Instants mit parse() und now() erzeugen
		final Instant silvester2013 = Instant.parse("2013-12-31T00:00:00Z");
		final Instant now = Instant.now();
		// Abfahrt 12:30 und Reisedauer 5 Stunden sowie 7 Minuten Versp�tung
		final Instant departureTime = Instant.parse("2015-02-07T12:30:00Z");
		final Instant expectedArrivalTime = departureTime.plus(5, ChronoUnit.HOURS);
		final Instant arrival = expectedArrivalTime.plus(Duration.ofMinutes(7));
		System.out.println("now: " + now);
		System.out.println("departure: " + departureTime);
		System.out.println("expected: " + expectedArrivalTime);
		System.out.println("arrival: " + arrival);

	}

}
