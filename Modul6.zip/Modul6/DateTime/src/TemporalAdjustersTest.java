import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.TemporalAdjusters;

public class TemporalAdjustersTest {

	public static void main(String[] args) {
		final LocalDate date = LocalDate.of(2022, Month.FEBRUARY, 7);
		
		LocalDate firstOfMonth = date.with(TemporalAdjusters.firstDayOfMonth());
		LocalDate lastofMonth = date.with(TemporalAdjusters.lastDayOfMonth());
		LocalDate firstOfNextMonth = date.with(TemporalAdjusters.firstDayOfNextMonth());
		LocalDate firstMondayInMonth = date.with(TemporalAdjusters.firstInMonth(DayOfWeek.MONDAY));
		LocalDate lastSaturdayInMonth = date.with(TemporalAdjusters.lastInMonth(DayOfWeek.SATURDAY));
		
		
		
		System.out.println("date: " + date);
		System.out.println("firstOfMonth: " + firstOfMonth);
		System.out.println("lastofMonth: " + lastofMonth);
		System.out.println("firstOfNextMonth: " + firstOfNextMonth + " war ein " + firstOfNextMonth.getDayOfWeek());
		System.out.println("firstMondayInMonth: " + firstMondayInMonth);
		System.out.println("lastSaturdayInMonth: " + lastSaturdayInMonth);
		
		System.out.println(date.with(TemporalAdjusters.lastInMonth(DayOfWeek.MONDAY)));
		System.out.println(date.with(TemporalAdjusters.dayOfWeekInMonth(6, DayOfWeek.MONDAY)));

	}

}
