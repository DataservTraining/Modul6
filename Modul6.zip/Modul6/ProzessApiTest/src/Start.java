import java.io.IOException;
import java.lang.module.ModuleDescriptor.Version;
import java.util.Optional;
import java.util.function.Predicate;

public class Start {
	
	

	public static void main(String[] args) throws IOException, InterruptedException {
		
//		// Prozess erzeugen
//		final String command = "sleep 60s";  // Linux
//		final String commandWin = "cmd timeout 60";  // Windows
//		final Process sleeper = Runtime.getRuntime().exec(commandWin);
//		System.out.println("Started process is " + sleeper.pid());
//		
//		
//		// Process => ProcessHandle
//		final ProcessHandle sleeperHandle = ProcessHandle.of(sleeper.pid()).orElseThrow(IllegalStateException::new);
//		final ProcessHandle sleeperHandle2 = sleeper.toHandle();
//		System.out.println("Same handle? " + sleeperHandle.equals(sleeperHandle2));
//		
//		// Exit Handler registrieren
//		final Runnable exitHandler = () -> System.out.println("exitHandler	called");
//		sleeperHandle.onExit().thenRun(exitHandler);
//		System.out.println("Registered exitHandler");
//		Thread.sleep(500);
//		
//		System.out.println("isAlive: " + sleeper.toHandle().isAlive());
//		
//		ProcessHandle.Info info = ProcessHandle.of(sleeper.pid()).get().info();
//		System.out.println("Argumente: " + info.arguments());
//		System.out.println("command: " + info.command());
//		System.out.println("commandLine: " + info.commandLine());
//		System.out.println("Startzeit: " + info.startInstant());
//		System.out.println("CPU-Zeit: " + info.totalCpuDuration());
//		System.out.println("User: " + info.user());
//		
//		// Den Prozess zerst�ren und ein wenig damit onExit() ausgef�hrt werden kann
//		System.out.println("Destroying process " + sleeperHandle.pid());
//		sleeperHandle.destroy();
//		System.out.println("isAlive: " + sleeper.toHandle().isAlive());
//		Thread.sleep(500);
//		System.out.println("isAlive: " + sleeper.toHandle().isAlive());
//		
//		System.out.println("Alle Prozesse:");
//		
//		ProcessHandle.allProcesses().forEach(System.out::println);
//		System.out.println("================================");
//		
//		Predicate<ProcessHandle> isUserPresent = o -> {
//			Optional<String> user = o.info().user();
//			return user.isPresent() && user.get().contains("Guido"); 
//		};
//		Predicate<ProcessHandle> isInfoPresent = o -> {
//			
//			return true; 
//		};
//		
//	     
//		ProcessHandle.allProcesses().filter(Predicate.not(isInfoPresent)).forEach(System.out::println);
//		
		  for (var pid : ProcessHandle.allProcesses().map(handle -> handle.pid()).toList()) {
	            if (ProcessHandle.of(pid).isEmpty()) {
	                System.out.println("Pid " + pid + " gibt keine Info aus User: " + ProcessHandle.of(pid));
	                continue;
	            }
	            
	            ProcessHandle.Info info = ProcessHandle.of(pid).get().info();
	            System.out.println("PID: " + pid);
	            System.out.println("Argumente: " + info.arguments());
	            System.out.println("Command: " + info.command());
	            System.out.println("Commandline: " + info.commandLine());
	            System.out.println("Startzeit: " + info.startInstant());
	            System.out.println("CPU-Zeit: " + info.totalCpuDuration());
	            System.out.println("User: " + info.user());
		  }
		  
		 
	}

}
