import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class Start {

	public static void main(String[] args) {
		Comparator<Integer> comparator = new Comparator<Integer>() {

			@Override
			public int compare(Integer o1, Integer o2) {
				
				return o1 < o2 ? -1 : 1;
			}
		
		};
		
		Set<Integer> integers = new TreeSet<>(comparator);
		
		Comparator<Integer> comparator2 = (Integer o1, Integer o2) -> { 
//																		System.out.println(o1); 
																		return o1 < o2 ? -1 : 1; 
																	  };
		
		Comparator<Integer> comparator3 = (o1, o2) -> o1 < o2 ? -1 : 1;
		
		Consumer<String> consumer1 = s1 -> System.out.println(s1);
		
		Supplier<Integer> supplier1 = () -> Integer.valueOf(3);
		Supplier<Integer> supplier2 = () -> 3;
		
		Set<Integer> integers2 = new TreeSet<>((p1, p2) -> p1.compareTo(p2));
		Set<Integer> integers3 = new TreeSet<>(Integer::compareTo);
		
		final List<String> names = Arrays.asList("Andy", "Michael", "Max", "Stefan");
		
				Collections.sort(names, new Comparator<String>(){
					@Override
					public int compare( final String str1, final String str2){
						return Integer.compare(str1.length(), str2.length());
					}
				});
				
				
				// Iteration und Ausgabe		
				final Iterator<String> it = names.iterator();
				while (it.hasNext()){
					System.out.print(it.next().length() + ", "); // 3, 4, 6, 7,
				}
				
				Collections.sort(names, (s1, s2) -> Integer.compare(s1.length(), s2.length()));
				names.forEach(s -> System.out.println(s));
				names.forEach(System.out::println);
				
				
			
				
	}

}
