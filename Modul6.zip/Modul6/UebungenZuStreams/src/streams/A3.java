package streams;
import java.util.function.Predicate;

class Person {
	private final String name;
	private final int age;

	public Person(final String name, final int age) {
		this.name = name;
		this.age = age;
	}

	public int getAge() {
		return age;
	}

	public boolean isAdult() {
		return getAge() >= 18;
	}
// ...
}

public class A3 {

	public static void main(String[] args) {
			final Predicate<Person> isAdultAsLambda = person -> person.getAge() >= 18;
			final Predicate<Person> isAdultAsMethodReference = Person::isAdult;
	}

}
