package streams;
import java.util.Arrays;
import java.util.List;

public class aufgabe1 {

	public static void main(String[] args) {
		final List<String> names = Arrays.asList("Tim", "Peter", "Mike");
		names.stream().forEach(System.out::println);

	}

}
