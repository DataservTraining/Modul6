import java.util.Arrays;
import java.util.Comparator;
import java.util.Optional;

public class Start {

	public static void main(String[] args) {
		final Integer[] sampleValues = {1,3,5,7,11,13,17,19};
		final Integer[] noValues = {};
		
		// Minimum und Maximum berechnen und ausgeben
		final Comparator<Integer> naturalOrder = Comparator.naturalOrder();
		
		final Optional<Integer> max = Arrays.stream(sampleValues).max(naturalOrder);
		final Optional<Integer> min = Arrays.stream(noValues).min(naturalOrder);
		System.out.println("max: " + max);
		System.out.println("min: " + min);
		
		// Pr�fe, ob es einen Wert gibt
		System.out.println("isPresent?: " + min.isPresent());
//		System.out.println("get()?: " + min.get());
		min.ifPresent(System.out::println);
		min.ifPresentOrElse(System.out::println, () -> System.out.println("kein Wert vorhanden"));
		// seit Java 8
		System.out.println("orElse: " + min.orElse(0));
		System.out.println("orElse: " + min.orElseGet(() -> Integer.valueOf(-1)));
		// seit Java 10
		System.out.println("orElse: " + min.orElseThrow());
		// seit Java 8
		System.out.println("orElse: " + min.orElseThrow(IllegalArgumentException::new));
		
		// Zugriff auf den Wert
		final Integer maxValue = max.get();
		System.out.println("maxValue: " + maxValue);
		// Konstruktionsmethoden
		final Optional<Integer> optionalFromValue = Optional.of(4711);
		final Optional<Double> optionalFromNull = Optional.ofNullable(null);
		
		System.out.println("from Value: " + optionalFromValue);
		System.out.println("from null: "+ optionalFromNull);

		
	}

}
