import java.util.Arrays;
import java.util.Random;
import java.util.function.Supplier;
import java.util.stream.Stream;

public class ToArrayTest {

	public static void main(String[] args) {
		// Zufallszahlen von 0 bis 100
		final Random random = new Random();
		final Supplier<Float> randomSupplier = () -> random.nextFloat() * 100;
		
		Stream<Float> zahlen = Stream.generate(randomSupplier).limit(7);
		Object[] array = zahlen.toArray();
		
		for(var element : array) {
			System.out.println(element);
		}
		

		System.out.println(Arrays.toString(array));
		System.out.println("Element type: " + array[0].getClass());
	}

}
