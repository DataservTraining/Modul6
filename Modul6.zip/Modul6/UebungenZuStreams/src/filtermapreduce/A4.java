package filtermapreduce;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class A4 {

	public static void main(String[] args) {
		Stream<String> inputs = Stream.of("Tim", "Tom", "Andy", "Mike", "Merten");
		// 4a
		final Map<Character, List<String>> grouped = inputs.collect(Collectors.groupingBy(n -> n.charAt(0)));
		System.out.println(grouped);
		
		// 4b
		
		inputs = Stream.of("Tim", "Tom", "Andy", "Mike", "Merten");
		final Map<Boolean, List<String>> partitioned = inputs.collect(Collectors.partitioningBy(n -> n.length() <= 3));
		System.out.println(partitioned);
		
		// 4c
		inputs = Stream.of("Tim", "Tom", "Andy", "Mike", "Merten");
		final Map<Character, Long> groupedAndCounted = inputs.collect(Collectors.groupingBy(n -> n.charAt(0), Collectors.counting()));
		System.out.println(groupedAndCounted);
	}

}
