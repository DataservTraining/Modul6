import java.util.List;
import java.util.TreeSet;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class PartitioningBy {

	public static void main(String[] args) {
		final List<Person> persons = DemoData.createPersons();
		final Predicate<Person> isFemale = person -> person.getGender() == Gender.FEMALE;
		System.out.println("Males and females in map");
		System.out.println(persons.stream().collect(Collectors.partitioningBy(isFemale)));
		System.out.println(" nmap to just names");
		System.out.println(persons.stream().collect(Collectors.partitioningBy(isFemale, Collectors.mapping(Person::getName, Collectors.toList()))));
		System.out.println(" nmap to unique cities");
		System.out.println(persons.stream().collect(Collectors.partitioningBy(isFemale, Collectors.mapping(Person::getCity, Collectors.toSet()))));
		System.out.println(" nmap to unique cities sorted");
		System.out.println(persons.stream().collect(Collectors.partitioningBy(isFemale, Collectors.mapping(Person::getCity, Collectors.toCollection(TreeSet::new)))));
	}

}
